//
//  colorCodeCell.swift
//  
//
//  Created by Five Admin on 6/20/19.
//

import UIKit

class colorCodeCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
