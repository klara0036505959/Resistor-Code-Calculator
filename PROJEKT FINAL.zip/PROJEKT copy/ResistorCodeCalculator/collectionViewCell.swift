//
//  collectionViewCell.swift
//  ResistorCodeCalculator
//
//  Created by Five Admin on 6/20/19.
//  Copyright © 2019 Five Admin. All rights reserved.
//

import UIKit

class collectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var labelColor: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

